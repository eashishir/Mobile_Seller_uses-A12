import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import CategorisTable from './CategorisTable';



const ProductsCategories = () => {
    const [categories, setCategories] = useState([])

    useEffect(() => {
        fetch('http://localhost:5000/categories')
            .then(res => res.json())
            .then(data => setCategories(data))
    }, [])

    console.log(categories);



    return (
        <div>
            <h2 className='text-center text-dark font-bold text-2xl'>Our Products <small className='text-2xl text-green-600'>Categories</small></h2>

            <div className='grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 my-3'>
                {
                    categories?.map(category => {
                        return (
                            <div key={category._id} className="card w-96 bg-base-100 shadow-xl">
                                <figure className="px-10 pt-10 ">
                                    <img src={category.logo} alt="Shoes" className="rounded-xl w-24" />
                                </figure>
                                <div className="card-body items-center text-center">
                                    <h2 className="card-title">{category.name}</h2>

                                    <div className="card-actions">
                                       <Link to={`/category/${category.categoryId}`}>click me</Link>
                                    </div>
                                </div>
                            </div>
                        )
                    })
                }
            </div>






            {/* {
            categories.map(categorie => <ProductsCategorie
            key={categorie._id}
            categorie={categorie}
            ></ProductsCategorie> )
           } */}
        </div>
    );
};

export default ProductsCategories;